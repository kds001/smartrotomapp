package com.example.smartrotom_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
