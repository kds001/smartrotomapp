import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart'; // Importar sqflite
import 'dashboard.dart';
import 'login_page.dart';
import 'database_helper.dart';

void main() async {
  // Asegúrate de que Flutter esté inicializado
  WidgetsFlutterBinding.ensureInitialized();

  // Inicializar la base de datos
  final DatabaseHelper databaseHelper = DatabaseHelper();
  await databaseHelper.database; // Inicializa la base de datos

  runApp(const SmartRotomApp());
}

class SmartRotomApp extends StatelessWidget {
  const SmartRotomApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SmartRotom App',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      initialRoute: '/', // Establece la ruta inicial
      routes: {
        '/': (context) => LoginPage(), // Pantalla de inicio
        '/dashboard': (context) => Dashboard(
          nombreEntrenador: ModalRoute.of(context)!.settings.arguments as String,
        ), // Pantalla de Dashboard
      },
      onUnknownRoute: (settings) {
        return MaterialPageRoute(builder: (context) => LoginPage());
      },
    );
  }
}

