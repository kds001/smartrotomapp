import 'package:flutter/material.dart';

// Dashboard Screen (Main Menu)
class Dashboard extends StatefulWidget {
  final String nombreEntrenador;

  // Constructor que acepta el parámetro nombreEntrenador
  Dashboard({Key? key, required this.nombreEntrenador}) : super(key: key);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  int _selectedIndex = 0;

  // Simulamos la foto de perfil del usuario
  final String profileImageUrl = 'assets/profile_image.png'; // Cambia esta ruta a la imagen deseada

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset(
              'SmartRotom.png', // Asegúrate de que la imagen esté en el directorio correcto
              height: 32,
            ),
            SizedBox(width: 8),
            Text('SmartRotom'),
          ],
        ),
        actions: [
          // Icono de mensajería
          IconButton(
            icon: Icon(Icons.message),
            onPressed: () {
              // Lógica para abrir la mensajería
              Navigator.pushNamed(context, '/mensajes'); // Asegúrate de tener esta ruta definida
            },
          ),
          // Foto de perfil del usuario
          CircleAvatar(
            backgroundImage: AssetImage(profileImageUrl),
            radius: 20,
          ),
          SizedBox(width: 16), // Espaciado entre la foto y el borde derecho
        ],
        backgroundColor: const Color.fromARGB(255, 255, 194, 194),
      ),
      body: _getBodyContent(_selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Inicio',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.card_membership),
            label: 'Tarjeta de Liga',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.group),
            label: 'Equipo Pokémon',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.pets),
            label: 'Pokédex',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.leaderboard),
            label: 'Clasificación',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.map),
            label: 'Mapa',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Configuración',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.red[800],
        unselectedItemColor: Colors.white,
        backgroundColor: Colors.black,
        type: BottomNavigationBarType.fixed,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget _getBodyContent(int index) {
    switch (index) {
      case 0:
        return _buildInicioSection();
      case 1:
        return _buildTarjetaLigaSection();
      case 2:
        return _buildEquipoPokemonSection();
      case 3:
        return _buildPokedexSection();
      case 4:
        return _buildClasificacionSection();
      case 5:
        return _buildMapaSection();
      case 6:
        return _buildConfiguracionSection();
      default:
        return Center(child: Text('Sección no disponible'));
    }
  }

  // Sección Inicio
  Widget _buildInicioSection() {
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Text(
            '¡Bienvenido/a entrenador/a ${widget.nombreEntrenador}! ',
            style: TextStyle(fontSize: 24),
          ),
          SizedBox(height: 20),
          _buildHistoriasSection(), // Añadiendo la sección de historias
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              // Acción para comenzar la aventura
            },
            child: Text('Comenzar Aventura'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          ),
        ],
      ),
    );
  }

  // Sección de Historias
  Widget _buildHistoriasSection() {
    return Container(
      height: 100,
      padding: EdgeInsets.all(8),
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          _buildHistoriaCircle("Tu Historia", "assets/tu_historia.png"), // Icono para "Tu Historia"
          SizedBox(width: 10),
          _buildHistoriaCircle("ColourPop", "assets/colourpop.png"), // Cambia estas rutas a las imágenes deseadas
          SizedBox(width: 10),
          _buildHistoriaCircle("SmartRotom", "assets/smartrotom_logo.png"),
          SizedBox(width: 10),
          _buildHistoriaCircle("Bellroy", "assets/bellroy_logo.png"),
          SizedBox(width: 10),
          _buildHistoriaCircle("Target", "assets/target_logo.png"),
        ],
      ),
    );
  }

  Widget _buildHistoriaCircle(String title, String imagePath) {
    return GestureDetector(
      onTap: () {
        // Acción al tocar la historia
        // Aquí puedes implementar una pantalla de detalle para la historia
      },
      child: Column(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundImage: AssetImage(imagePath), // Imagen de la historia
          ),
          SizedBox(height: 5),
          Text(title, style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  // Sección Tarjeta de Liga
  Widget _buildTarjetaLigaSection() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text('Tarjeta de Liga', style: TextStyle(fontSize: 24)),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              // Aquí puedes implementar la lógica para importar la tarjeta de liga
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Importar tarjeta de liga')),
              );
            },
            child: Text('Importar Tarjeta de Liga'),
          ),
        ],
      ),
    );
  }

  // Sección Equipo Pokémon
  Widget _buildEquipoPokemonSection() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text('Equipo Pokémon', style: TextStyle(fontSize: 24)),
          // Añadir componentes del equipo Pokémon
        ],
      ),
    );
  }

  // Sección Pokédex
  Widget _buildPokedexSection() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text('Pokédex', style: TextStyle(fontSize: 24)),
          SizedBox(height: 20),
          // Aquí puedes añadir la lógica para mostrar Pokémon
          // Por ejemplo, usando ListView para mostrar una lista de Pokémon
          Expanded(
            child: ListView.builder(
              itemCount: 10, // Cambia esto según el número de Pokémon
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text('Pokémon ${index + 1}'), // Cambia esto a los nombres reales de los Pokémon
                  onTap: () {
                    // Acción al tocar un Pokémon
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // Sección Clasificación
  Widget _buildClasificacionSection() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text('Clasificación', style: TextStyle(fontSize: 24)),
          // Añadir componentes de la clasificación
        ],
      ),
    );
  }

  // Sección Mapa
  Widget _buildMapaSection() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text('Mapa', style: TextStyle(fontSize: 24)),
          // Añadir componentes del mapa
        ],
      ),
    );
  }

  // Sección Configuración
  Widget _buildConfiguracionSection() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text('Configuración', style: TextStyle(fontSize: 24)),
          ListTile(
            title: Text("Cerrar sesión"),
            onTap: () {
              // Implementar la lógica de cierre de sesión
              Navigator.of(context).pushReplacementNamed('/login'); // Redirigir a la pantalla de inicio de sesión
            },
          ),
          // Añadir más opciones de configuración aquí
        ],
      ),
    );
  }
}
