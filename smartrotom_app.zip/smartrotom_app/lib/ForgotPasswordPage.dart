import 'package:flutter/material.dart';
import 'login_page.dart'; // Importa la página de inicio de sesión
import 'database_helper.dart'; // Importa tu helper de base de datos

class ForgotPasswordPage extends StatelessWidget {
  final TextEditingController _emailController = TextEditingController();
  final DatabaseHelper _databaseHelper = DatabaseHelper(); // Instancia del helper de base de datos

  void _sendEmail(BuildContext context) async {
    String email = _emailController.text;

    // Verificar si el email está vacío
    if (email.isNotEmpty) {
      // Consultar la base de datos para verificar si el email existe
      List<Map<String, dynamic>> users = await _databaseHelper.getUsers();
      bool emailExists = false;

      for (var user in users) {
        if (user['email'] == email) {
          emailExists = true;
          break;
        }
      }

      if (emailExists) {
        // Simulación de envío de correo
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Correo enviado a $email para recuperar la contraseña')),
        );

        Navigator.pop(context); // Regresar a la página de inicio de sesión
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Este correo no está registrado')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Por favor, introduce tu correo electrónico')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.white,
              const Color.fromARGB(255, 250, 117, 150),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  'SmartRotom.png', // Asegúrate de que la ruta sea correcta
                  height: 100,
                ),
                SizedBox(height: 20),
                Text(
                  'Recuperar Contraseña',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'Correo electrónico',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => _sendEmail(context),
                  child: Text('Enviar'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 199, 146, 169),
                    minimumSize: Size(double.infinity, 50),
                  ),
                ),
                SizedBox(height: 10),
                TextButton(
                  onPressed: () {
                    // Regresar a la página de inicio de sesión
                    Navigator.pop(context);
                  },
                  child: Text('Volver a iniciar sesión'),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
